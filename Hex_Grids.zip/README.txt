README

These files are comma separated values describing arcs on a geodesic surface.
Each line consists of a start point and an end point.
The coordinate system is Latitude - Longitude.
The format for a line segment is:
" Latitude-1,Longitude-1,Latitude-2,Longitude-2 "
If a different seperator is required, use the "Find and Replace" feature on your text editor.
All files are plain text and editable.
