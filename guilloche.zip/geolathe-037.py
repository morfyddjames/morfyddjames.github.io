
#
#
#
#	Virtual Geometric Lathe v-00.01.037
#
#
#	THIS APPLICATION PRODUCES A VECTOR IMAGE OF A GUILLOCHE FIGURE PRODUCED BY A VIRTUAL GEOMETRIC LATHE
#	CALL ON THE COMMAND LINE:  "python3 geolathe-037.py"
#	TWO WINDOWS WILL OPEN, THE CONTROL WINDOW AND THE DISPLAY WINDOW
#	USE THE SLIDERS ON THE CONTROL WINDOW TO ALTER THE COMPONENT VALUES
#	YOU SHOULD SEE CHANGES TAKE PLACE IMMEDIATELY IN THE DISPLAYED FIGURE
#
#	THIS APP REQUIRES NUMPY AND MATPLOTLIB
#	python3 -m pip install numpy
#	python3 -m pip install matplotlib
#
#
#	TODO:
#	-OUTPUT RAW FUNCTION TO TERMINAL OR TEXT FILE.
#	-FIX PHASE SHIFT 0-360
#	-FIX FOLD AMPLITUDE, LINK TO WAVE COUNT?
#	-FIX INTEGER SLIDERS PROPERLY
#
#	 13 SEPT 2022
#




import numpy as np
import matplotlib.pyplot as plt
from matplotlib.widgets import Slider, Button


#t, init_ORB, init_FRQ, init_ROD, init_PHZ_r, init_AMP_r, init_WAV_r, init_DSK, init_PHZ_d, init_AMP_d, init_WAV_d, init_PHZ_f, init_AMP_f, init_WAV_f
#t,      ORB,      FRQ,      ROD,      PHZ_r,      AMP_r,      WAV_r,      DSK,      PHZ_d,      AMP_d,      WAV_d,      PHZ_f,      AMP_f,      WAV_f 

# The parametrized function to be plotted  BACKUP  BACKUP  BACKUP  BACKUP  BACKUP  BACKUP  BACKUP  BACKUP  BACKUP  BACKUP  BACKUP 
#def f(t, ORB, FRQ, ROD, PHZ_r, AMP_r, WAV_r, DSK, PHZ_d, AMP_d, WAV_d, PHZ_f, AMP_f, WAV_f ):
#    return np.cos(ORB*(t)+np.sin(ORB*WAV_f*((t+PHZ_f*(RAD)/(WAV_f+1))))*(AMP_f/(WAV_f+1)))*((AMP_d*np.cos(WAV_d*(t+PHZ_d*(RAD)/(WAV_d+1))*ORB)+DSK)*np.sin(FRQ*t)#+AMP_r*np.cos(WAV_r*(t+PHZ_r*(RAD)/(WAV_r+1))*ORB)+ROD)

#def g(t, ORB, FRQ, ROD, PHZ_r, AMP_r, WAV_r, DSK, PHZ_d, AMP_d, WAV_d, PHZ_f, AMP_f, WAV_f):
#    return np.sin(ORB*(t)+np.sin(ORB*WAV_f*((t+PHZ_f*(RAD)/(WAV_f+1))))*(AMP_f/(WAV_f+1)))*((AMP_d*np.cos(WAV_d*(t+PHZ_d*(RAD)/(WAV_d+1))*ORB)+DSK)*np.sin(FRQ*t)+AMP_r*np.cos(WAV_r*(t+PHZ_r*(RAD)/(WAV_r+1))*ORB)+ROD)





# The parametric functions
def f(t, ORB, FRQ, ROD, PHZ_r, AMP_r, WAV_r, DSK, PHZ_d, AMP_d, WAV_d, PHZ_f, AMP_f, WAV_f ):
    return np.cos(ORB*(t)+np.sin(ORB*WAV_f*((t+PHZ_f*(RAD)/(WAV_f+1))))*(AMP_f/(WAV_f+1)))*((AMP_d*np.cos(WAV_d*(t+PHZ_d*(RAD)/(WAV_d+1))*ORB)+DSK)*np.sin(FRQ*t)+AMP_r*np.cos(WAV_r*(t+PHZ_r*(RAD)/(WAV_r+1))*ORB)+ROD)

def g(t, ORB, FRQ, ROD, PHZ_r, AMP_r, WAV_r, DSK, PHZ_d, AMP_d, WAV_d, PHZ_f, AMP_f, WAV_f):
    return np.sin(ORB*(t)+np.sin(ORB*WAV_f*((t+PHZ_f*(RAD)/(WAV_f+1))))*(AMP_f/(WAV_f+1)))*((AMP_d*np.cos(WAV_d*(t+PHZ_d*(RAD)/(WAV_d+1))*ORB)+DSK)*np.sin(FRQ*t)+AMP_r*np.cos(WAV_r*(t+PHZ_r*(RAD)/(WAV_r+1))*ORB)+ROD)


plt.rcParams["figure.figsize"] = [8.0, 8.0]
plt.rcParams["figure.autolayout"] = True

N = 8000
t = np.linspace(0, 2 * np.pi, N)

#  initial values
RAD = np.pi/180.0

init_FRQ = 181.0
init_ORB = 13.0

init_ROD = 7.0
init_DSK = 2.0

init_WAV_r = 8.0
init_AMP_r = 0.7
init_PHZ_r = 0.0

init_WAV_d = 16.0
init_AMP_d = 0.2 
init_PHZ_d = 0.0

init_WAV_f = 0.0
init_AMP_f = 1.0
init_PHZ_f = 0.0

init_OFF_f = 0.0


# The figure and the line

fig1, ax = plt.subplots()
line, = plt.plot(f(t, init_ORB, init_FRQ, init_ROD, init_PHZ_r, init_AMP_r, init_WAV_r, init_DSK, init_PHZ_d, init_AMP_d, init_WAV_d, init_PHZ_f, init_AMP_f, init_WAV_f ), g(t, init_ORB, init_FRQ, init_ROD, init_PHZ_r, init_AMP_r, init_WAV_r, init_DSK, init_PHZ_d, init_AMP_d, init_WAV_d, init_PHZ_f, init_AMP_f, init_WAV_f ), lw=1)

plt.rcParams["figure.figsize"] = [8.0, 8.0]
plt.rcParams["figure.autolayout"] = True

ax.set_axis_off()

fig2, aQ = plt.subplots()
aQ.set_axis_off()

##############################################################

# Make a horizontal slider to control the Frequency.
axFRQ = plt.axes([0.25, 0.90, 0.65, 0.03])
FRQ_slider = Slider(
    ax=axFRQ,
    label='Frequency [1-337]',
    valmin=1.0,
    valmax=337.,
    valinit=init_FRQ,
    valstep=1,
    orientation="horizontal")

# Horizontal slider to control the orbits.
axORB = plt.axes([0.25, 0.85, 0.65, 0.03])
ORB_slider = Slider(
    ax=axORB,
    label='Orbits [1-17]',
    valmin=1.0,
    valmax=17.,
    valinit=init_ORB,
    valstep=1,
    orientation="horizontal")

##############################################################

# Make a horizontal slider to control the Rod Length.
axROD = plt.axes([0.25, 0.75, 0.65, 0.03])
ROD_slider = Slider(
    ax=axROD,
    label='Rod Length [1.-20.]',
    valmin=1.0,
    valmax=20.,
    valinit=init_ROD,
    orientation="horizontal")

## Make a horizontal slider to control the Disk diameter.
axDSK = plt.axes([0.25, 0.70, 0.65, 0.03])
DSK_slider = Slider(
    ax=axDSK,
    label='Disk Diameter [1.-10.]',
   valmin=0.2,
    valmax=20.,
    valinit=init_DSK,
    orientation="horizontal")

##############################################################

# Make a horizontal slider to control the Rod wave count.
axWAVr = plt.axes([0.25, 0.60, 0.65, 0.03])
WAVr_slider = Slider(
    ax=axWAVr,
    label='Rod wave count [0-36]',
    valmin=0.0,
    valmax=36.,
    valinit=init_WAV_r,
    valstep=1,
    orientation="horizontal")

# Make a horizontal slider to control the Rod amplitude.
axAMPr = plt.axes([0.25, 0.55, 0.65, 0.03])
AMPr_slider = Slider(
    ax=axAMPr,
    label='Rod Ampl [0-10]',
    valmin=0.0,
    valmax=10.,
    valinit=init_AMP_r,
    orientation="horizontal")

## Make a horizontal slider to control the Rod phase.
axPHZr = plt.axes([0.25, 0.50, 0.65, 0.03])
PHZr_slider = Slider(
    ax=axPHZr,
    label='Rod Phase [0-90]',
    valmin=0.0,
    valmax=90.,
    valinit=init_PHZ_r,
    orientation="horizontal")

##############################################################

## Make a horizontal slider to control the Disk Waves.
axWAVd = plt.axes([0.25, 0.40, 0.65, 0.03])
WAVd_slider = Slider(
    ax=axWAVd,
    label='Disk Wave Count [0-36]',
    valmin=0.0,
    valmax=36.,
    valinit=init_WAV_d,
    valstep=1,
    orientation="horizontal")

## Make a horizontal slider to control the Disk amplitude.
axAMPd = plt.axes([0.25, 0.35, 0.65, 0.03])
AMPd_slider = Slider(
    ax=axAMPd,
    label='Disk Amplitude [0-10]',
    valmin=0.0,
    valmax=10.,
    valinit=init_AMP_d,
    orientation="horizontal")

## Make a horizontal slider to control the Disk phase.
axPHZd = plt.axes([0.25, 0.30, 0.65, 0.03])
PHZd_slider = Slider(
    ax=axPHZd,
    label='Disk Phase [0-90]',
    valmin=0.0,
    valmax=90.,
    valinit=init_PHZ_d,
    orientation="horizontal")

##############################################################

## Make a horizontal slider to control the Fold wave count.
axWAVf = plt.axes([0.25, 0.20, 0.65, 0.03])
WAVf_slider = Slider(
    ax=axWAVf,
    label='fold Wave Count [0-36]',
    valmin=0.0,
    valmax=36.,
    valinit=init_WAV_f,
    valstep=1,
    orientation="horizontal")

# Make a horizontal slider to control the Fold amplitude.
axAMPf = plt.axes([0.25, 0.15, 0.65, 0.03])
AMPf_slider = Slider(
    ax=axAMPf,
    label='fold amplitude [0-4.]',
    valmin=0.0,
    valmax=4.,
    valinit=init_AMP_f,
    orientation="horizontal")

# Make a horizontal slider to control the Fold phase.
axPHZf = plt.axes([0.25, 0.10, 0.65, 0.03])
PHZf_slider = Slider(
    ax=axPHZf,
    label='fold phase  [0-90]',
    valmin=0.0,
    valmax=90.,
    valinit=init_PHZ_f,
    orientation="horizontal")

##############################################################

# The function to be called anytime a slider's value changes
def update(val):
    line.set_ydata(f(t, np.floor(ORB_slider.val), np.floor(FRQ_slider.val), ROD_slider.val, PHZr_slider.val, AMPr_slider.val, np.floor(WAVr_slider.val), DSK_slider.val, PHZd_slider.val, AMPd_slider.val, np.floor(WAVd_slider.val), PHZf_slider.val, AMPf_slider.val, np.floor(WAVf_slider.val)    ))
    fig1.canvas.draw_idle()
    line.set_xdata(g(t, np.floor(ORB_slider.val), np.floor(FRQ_slider.val), ROD_slider.val, PHZr_slider.val, AMPr_slider.val, np.floor(WAVr_slider.val), DSK_slider.val, PHZd_slider.val, AMPd_slider.val, np.floor(WAVd_slider.val), PHZf_slider.val, AMPf_slider.val, np.floor(WAVf_slider.val)   ))
    fig1.canvas.draw_idle()


# register the update function with each slider
ORB_slider.on_changed(update)
FRQ_slider.on_changed(update)
ROD_slider.on_changed(update)
#
PHZr_slider.on_changed(update)
AMPr_slider.on_changed(update)
WAVr_slider.on_changed(update)
#
DSK_slider.on_changed(update)
PHZd_slider.on_changed(update)
AMPd_slider.on_changed(update)
WAVd_slider.on_changed(update)
#
PHZf_slider.on_changed(update)
AMPf_slider.on_changed(update)
WAVf_slider.on_changed(update)


# Create a `matplotlib.widgets.Button` to reset the sliders to initial values.
resetax = plt.axes([0.8, 0.025, 0.1, 0.04])
button = Button(resetax, 'Reset', hovercolor='0.975')


def reset(event):
	ORB_slider.reset()
	FRQ_slider.reset()
	ROD_slider.reset()
	
	PHZr_slider.reset()
	AMPr_slider.reset()
	WAVr_slider.reset()
	
	DSK_slider.reset()
	PHZd_slider.reset()
	AMPd_slider.reset()
	WAVd_slider.reset()

	PHZf_slider.reset()
	AMPf_slider.reset()
	WAVf_slider.reset()
#
#
button.on_clicked(reset)
#
plt.show()

#############################################################################
#







